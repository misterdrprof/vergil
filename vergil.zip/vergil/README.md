vergil discord bot for misterdrprof's colorful traders discord

contains basic moderation and rocket league features
